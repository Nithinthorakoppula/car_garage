from django.apps import AppConfig


class MycarConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "mycar"
