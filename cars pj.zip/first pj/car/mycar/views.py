from django.shortcuts import render,redirect
import requests
from bs4 import BeautifulSoup
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from mycar.models import Useradd,Contact
from django.contrib.auth.decorators import login_required



url="https://www.zigwheels.com/mahindra-cars"
resp=requests.get(url).content
soup=BeautifulSoup(resp,'html.parser')
mahindraimg=[]
mahindralink=[]
mahindratitle=[]
mahindraprice=[]
links1=soup.find_all('div',class_="clr rel mk-img-h mke-lft")
links=soup.find_all('div',class_="p-15 pt-10 mke-ryt rel")
linkspri=soup.find_all('div',class_="clr-bl")
for t in links1:
    k1=t.img['src']
    mahindraimg.append(k1)
for e in links:
    n1=e.a['href']
    n2=e.a['title']
    mahindratitle.append(n2)
    mahindralink.append(n1)
for d in linkspri:
    c1=d.text
    mahindraprice.append(c1)



mylist1=zip(mahindraimg,
mahindralink,
mahindratitle,
mahindraprice)
def Mahindra(request):
    return render(request,"Mahindra.html",{ 'mylist1':mylist1})

url0="https://www.zigwheels.com/upcoming-cars"
resp0=requests.get(url0).content
soup9=BeautifulSoup(resp0,'html.parser')
aimg=[]
atit=[]
apri=[]
al=[]
links0=soup9.find_all("div",class_="clr rel mk-img-h mke-lft")
links9=soup9.find_all("div",class_="b fnt-15")
lin=soup9.find_all("div",class_="p-15 pt-10 mke-ryt rel")
for n1 in lin:
    o7="https://www.zigwheels.com"+n1.a['href']
    al.append(o7)
for o in links0:
    o2=o.img['title']
    atit.append(o2)
    o1=o.img['src']  
    aimg.append(o1)
for m in links9:
    m1=m.text
    apri.append(m1)
mylist3=zip(aimg,
atit,
apri,al
)

@login_required(login_url='login')

def car(request):

    return render(request,"base.html",{ 'mylist3':mylist3})


def contact(request):

    return render(request,"contact.html")


url1="https://www.zigwheels.com/tata-cars"
resp1=requests.get(url1).content
soup1=BeautifulSoup(resp1,'html.parser')
Tataimg=[]
Tatalink=[]
Tatatitle=[]
Tataprice=[]
link2=soup1.find_all('div',class_="clr rel mk-img-h mke-lft")
link3=soup1.find_all('div',class_="p-15 pt-10 mke-ryt rel")
linkspr=soup1.find_all('div',class_="clr-bl")
for t in link2:
    t1=t.img['src']
    Tataimg.append(t1)
for e in link3:
    f1=e.a['href']
    f2=e.a['title']
    Tatatitle.append(f2)
    Tatalink.append(f1)
for d in linkspr:
    b1=d.text
    Tataprice.append(b1)



mylist=zip(Tataimg,
Tatalink,
Tatatitle,
Tataprice)
def TataMotors(request):
    return render(request,"TataMotors.html",{ 'mylist':mylist})


url2="https://www.zigwheels.com/toyota-cars"
resp2=requests.get(url2).content
soup2=BeautifulSoup(resp2,'html.parser')
Toyotaimg=[]
Toyotalink=[]
Toyotatitle=[]
Toyotaprice=[]
links2=soup2.find_all('div',class_="clr rel mk-img-h mke-lft")
links3=soup2.find_all('div',class_="p-15 pt-10 mke-ryt rel")
linkspri=soup2.find_all('div',class_="clr-bl")
for t in links2:
    t1=t.img['src']
    Toyotaimg.append(t1)
for e in links3:
    e1=e.a['href']
    e2=e.a['title']
    Toyotatitle.append(e2)
    Toyotalink.append(e1)
for d in linkspri:
    d1=d.text
    Toyotaprice.append(d1)



mylist2=zip(Toyotaimg,
Toyotalink,
Toyotatitle,
Toyotaprice)
def Toyota(request):
    return render(request,"Toyota.html",{ 'mylist2':mylist2})
def login_user(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user= authenticate(username=username, password=password)
        if user is not None:
            login(request,user)
        return redirect("home")
    return render(request,"login.html")
def register(request):

    if request.method=="POST":

        username=request.POST.get("username")

        password=request.POST.get("password")

        email=request.POST.get("email")

        c = User.objects.create_user(username=username,email=email,password=password)

        c.save()

        # return redirect("mycar")
        return redirect("login")

    

    return render(request,"register.html")


def logout_user(request):

    logout(request)

    # return redirect("mycar")
    return redirect("login")






def contact(request):

    if request.method=="POST":

        name=request.POST['name']

        email=request.POST['email']

        message=request.POST['message']
        



        c=Contact(name=name,email=email,message=message)

        c.save()
        return redirect("home")


    return render(request,"contact.html")

       


